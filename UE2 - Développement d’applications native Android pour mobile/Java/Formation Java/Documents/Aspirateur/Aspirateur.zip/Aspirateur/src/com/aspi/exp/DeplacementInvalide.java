package com.aspi.exp;

public class DeplacementInvalide extends Exception {

	private static final long serialVersionUID = 1L;

	public DeplacementInvalide() {
		super();
	}

	public DeplacementInvalide(String aMessage, Throwable aCause) {
		super(aMessage, aCause);
	}

	public DeplacementInvalide(String aMessage) {
		super(aMessage);
	}

	public DeplacementInvalide(Throwable aCause) {
		super(aCause);
	}
}
