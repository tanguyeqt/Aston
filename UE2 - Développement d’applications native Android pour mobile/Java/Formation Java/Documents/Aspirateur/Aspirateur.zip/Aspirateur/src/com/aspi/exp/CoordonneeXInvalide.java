package com.aspi.exp;

public class CoordonneeXInvalide extends CoordonneeInvalide {

	private static final long serialVersionUID = 1L;

	public CoordonneeXInvalide() {
		super();
	}

	public CoordonneeXInvalide(String aMessage, Throwable aCause) {
		super(aMessage, aCause);
	}

	public CoordonneeXInvalide(String aMessage) {
		super(aMessage);
	}

	public CoordonneeXInvalide(Throwable aCause) {
		super(aCause);
	}
}
