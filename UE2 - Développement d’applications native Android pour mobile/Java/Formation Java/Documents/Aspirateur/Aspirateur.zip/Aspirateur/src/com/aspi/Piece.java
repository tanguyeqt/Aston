package com.aspi;

import com.aspi.exp.CoordonneeInvalide;
import com.aspi.exp.CoordonneeXInvalide;
import com.aspi.exp.CoordonneeYInvalide;
import com.aspi.exp.DeplacementInvalide;
import com.aspi.exp.DirectionInvalide;

public class Piece {
	public final static char DIRECTION_LEFT = 'G';
	public final static char DIRECTION_RIGHT = 'D';
	public final static char DIRECTION_FRONT = 'A';

	private Position position;

	// [Y][X]
	private int[][] grille;

	public Piece() {
		this(1, 1);
	}

	public Piece(int aHeight, int aWidth) {
		this.grille = new int[aHeight][aWidth];
	}

	public void setPositionInitiale(int aX, int aY, char anOrientation) throws CoordonneeInvalide {
		this.position = new Position();
		// Afin de marquer la grille
		this.setPosition(aX, aY, anOrientation);
	}

	public void move(char aDirection) throws DeplacementInvalide, DirectionInvalide {
		if (this.position == null) {
			throw new RuntimeException("Il faut initilialiser la position en premier via setPositionInitiale");
		}
		Position actuelle = new Position(this.position.getX(), this.position.getY(), this.position.getOrientation());
		try {
			switch (this.position.getOrientation()) {
			case Position.EAST:
				switch (aDirection) {
				case DIRECTION_LEFT:
					this.setPosition(this.position.getX(), this.position.getY(), Position.NORTH);
					break;
				case DIRECTION_RIGHT:
					this.setPosition(this.position.getX(), this.position.getY(), Position.SOUTH);
					break;
				case DIRECTION_FRONT:
					this.setPosition(this.position.getX() + 1, this.position.getY(), this.position.getOrientation());
					break;
				default:
					throw new DirectionInvalide();
				}
				break;
			case Position.WEST:
				switch (aDirection) {
				case DIRECTION_LEFT:
					this.setPosition(this.position.getX(), this.position.getY(), Position.SOUTH);
					break;
				case DIRECTION_RIGHT:
					this.setPosition(this.position.getX(), this.position.getY(), Position.NORTH);
					break;
				case DIRECTION_FRONT:
					this.setPosition(this.position.getX() - 1, this.position.getY(), this.position.getOrientation());
					break;
				default:
					throw new DirectionInvalide();
				}
				break;
			case Position.SOUTH:
				switch (aDirection) {
				case DIRECTION_LEFT:
					this.setPosition(this.position.getX(), this.position.getY(), Position.EAST);
					break;
				case DIRECTION_RIGHT:
					this.setPosition(this.position.getX(), this.position.getY(), Position.WEST);
					break;
				case DIRECTION_FRONT:
					this.setPosition(this.position.getX(), this.position.getY() - 1, this.position.getOrientation());
					break;
				default:
					throw new DirectionInvalide();
				}
				break;
			case Position.NORTH:
				switch (aDirection) {
				case DIRECTION_LEFT:
					this.setPosition(this.position.getX(), this.position.getY(), Position.WEST);
					break;
				case DIRECTION_RIGHT:
					this.setPosition(this.position.getX(), this.position.getY(), Position.EAST);
					break;
				case DIRECTION_FRONT:
					this.setPosition(this.position.getX(), this.position.getY() + 1, this.position.getOrientation());
					break;
				default:
					throw new DirectionInvalide();
				}
				break;
			}
			if (!actuelle.sameXY(this.position)) {
				// [Y][X]
				this.grille[actuelle.getY()][actuelle.getX()] = 0;
			}
		} catch (CoordonneeInvalide lcExp) {
			throw new DeplacementInvalide(lcExp);
		}

	}

	private void setPosition(int aX, int aY, char anOrientation) throws CoordonneeInvalide {
		if (this.position == null) {
			throw new RuntimeException("Il faut initilialiser la position en premier via setPositionInitiale");
		}

		if (!this.validateX(aX)) {
			throw new CoordonneeXInvalide();
		}
		if (!this.validateY(aY)) {
			throw new CoordonneeYInvalide();
		}

		this.position.setX(aX);
		this.position.setY(aY);
		this.position.setOrientation(anOrientation);
		// [Y][X]
		this.grille[aY][aX] = anOrientation;
	}

	private boolean validateX(int aX) {
		return (aX >= 0) && (aX < this.grille[0].length);
	}

	private boolean validateY(int aY) {
		return (aY >= 0) && (aY < this.grille.length);
	}

	@Override
	public String toString() {
		StringBuffer buff = new StringBuffer();
		// Permet de placer le 0,0 en bas � gauche
		for (int x = this.grille.length - 1; x >= 0; x--) {
			for (int y = 0; y < this.grille[x].length; y++) {
				int val = this.grille[x][y];
				if (val == 0) {
					buff.append(val);
				} else {
					buff.append((char) val);
				}
				buff.append(' ');
			}
			buff.append('\n');
		}
		return buff.toString();
	}
}
