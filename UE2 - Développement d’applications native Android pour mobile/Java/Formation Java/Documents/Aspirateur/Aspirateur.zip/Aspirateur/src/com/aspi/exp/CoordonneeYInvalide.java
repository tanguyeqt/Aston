package com.aspi.exp;

public class CoordonneeYInvalide extends CoordonneeInvalide {

	private static final long serialVersionUID = 1L;

	public CoordonneeYInvalide() {
		super();
	}

	public CoordonneeYInvalide(String aMessage, Throwable aCause) {
		super(aMessage, aCause);
	}

	public CoordonneeYInvalide(String aMessage) {
		super(aMessage);
	}

	public CoordonneeYInvalide(Throwable aCause) {
		super(aCause);
	}
}
