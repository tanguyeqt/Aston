package com.aspi.exp;

public class DirectionInvalide extends Exception {

	private static final long serialVersionUID = 1L;

	public DirectionInvalide() {
		super();
	}

	public DirectionInvalide(String aMessage, Throwable aCause) {
		super(aMessage, aCause);
	}

	public DirectionInvalide(String aMessage) {
		super(aMessage);
	}

	public DirectionInvalide(Throwable aCause) {
		super(aCause);
	}
}
