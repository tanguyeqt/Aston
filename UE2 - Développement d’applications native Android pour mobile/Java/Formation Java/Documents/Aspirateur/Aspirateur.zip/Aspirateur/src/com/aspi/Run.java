package com.aspi;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class Run {

	public static void main(String[] args) {
		File fichier = new File("T:/Workspace/Aspirateur/in/instruction.txt");
		Piece piece = null;
		try (FileReader fr = new FileReader(fichier); BufferedReader br = new BufferedReader(fr)) {
			// Premiere ligne taille de la piece
			String taillePiece = br.readLine();
			String[] tailles = taillePiece.split(" ");
			piece = new Piece(Integer.parseInt(tailles[0]), Integer.parseInt(tailles[1]));
			// seconde ligne position initiale
			String postionInitiale = br.readLine();
			String[] positions = postionInitiale.split(" ");
			piece.setPositionInitiale(Integer.parseInt(positions[0]), Integer.parseInt(positions[1]),
					positions[2].charAt(0));
			// derniere ligne, instruction
			String instructions = br.readLine();
			System.out.println(piece);
			for (int i = 0; i < instructions.length(); i++) {
				char direction = instructions.charAt(i);
				piece.move(direction);
				// Pour voir ce qui ce passe
				System.out.println(piece);
			}
		} catch (Exception e) {
			System.err.println("Erreur lors de la lecture des instructions");
			e.printStackTrace();
			System.exit(-1);
		}
		// Pas besoin de finally car utilisation des ressources (gestion
		// automatique des finally en Java7)
		System.exit(0);
	}

}
