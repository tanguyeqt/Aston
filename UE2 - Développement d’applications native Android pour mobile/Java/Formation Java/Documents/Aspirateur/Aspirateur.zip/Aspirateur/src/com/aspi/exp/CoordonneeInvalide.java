package com.aspi.exp;

public abstract class CoordonneeInvalide extends Exception {

	private static final long serialVersionUID = 1L;

	public CoordonneeInvalide() {
		super();
	}

	public CoordonneeInvalide(String aMessage, Throwable aCause) {
		super(aMessage, aCause);
	}

	public CoordonneeInvalide(String aMessage) {
		super(aMessage);
	}

	public CoordonneeInvalide(Throwable aCause) {
		super(aCause);
	}
}
