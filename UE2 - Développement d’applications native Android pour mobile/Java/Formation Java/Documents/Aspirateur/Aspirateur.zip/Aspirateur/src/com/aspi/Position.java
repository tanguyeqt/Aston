package com.aspi;

public class Position {

	public final static char NORTH = 'N';
	public final static char EAST = 'E';
	public final static char WEST = 'W';
	public final static char SOUTH = 'S';

	private int x;
	private int y;
	private char orientation;

	public Position() {
		this(0, 0, Position.NORTH);
	}

	public Position(int aX, int aY, char anOrientation) {
		this.setX(aX);
		this.setY(aY);
		this.setOrientation(anOrientation);
	}

	public int getX() {
		return this.x;
	}

	public void setX(int aX) {
		this.x = aX;
	}

	public int getY() {
		return this.y;
	}

	public void setY(int aY) {
		this.y = aY;
	}

	public char getOrientation() {
		return this.orientation;
	}

	public void setOrientation(char aOrientation) {
		this.orientation = aOrientation;
	}

	@Override
	public int hashCode() {
		return (this.getClass().getName() + "_" + this.toString()).hashCode();
	}

	public boolean sameXY(Position other) {
		if (this == other) {
			return true;
		}
		if (other == null) {
			return false;
		}
		return (this.x == other.x) && (this.y == other.y);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (obj instanceof Position) {
			Position other = (Position) obj;
			return (this.orientation == other.orientation) && this.sameXY(other);
		}
		return false;
	}

	@Override
	public String toString() {
		StringBuffer buff = new StringBuffer();
		buff.append(this.getX()).append(',').append(this.getY()).append(',').append(this.getOrientation());
		return buff.toString();
	}

}
