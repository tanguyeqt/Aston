package fr;

import fr.dessin.Point2D;

/**
 * La classe de lancement. <br/>
 */
public class Run {

	/**
	 * Pour tester. <br/>
	 *
	 * @param args
	 *            les arguments
	 */
	public static void main(String[] args) {
		// Creation d'une variable de type Point2D et qui s'appelera p1
		// Avant d'utiliser un objet il faut l'instancier
		// On utilise ici son constructeur sans parametre
		Point2D p1 = new Point2D();
		System.out.println("Par defaut :");
		// Appel de la methode afficher sur l'instance p1
		p1.afficher();
		p1.translater(5, 8);
		System.out.println("Apres translation :");
		p1.afficher();
		p1.setX(19);
		System.out.println("Apres modification de sa valeur en x :");
		p1.afficher();

		// Utilisation du second constructeur
		// Le second constructeur prend deux parametres de type entier
		Point2D p2 = new Point2D(5, 5);
		System.out.println("Avec l'autre constructeur :");
		// Appel de la methode afficher sur l'instance p2
		p2.afficher();
		p2.translater(5, 8);
		System.out.println("Apres translation :");
		p2.afficher();
		p2.setY(19);
		System.out.println("Apres modification de sa valeur en y :");
		p2.afficher();

		// p1 et p2 sont
		// - deux variables locales a la methode main
		// - deux instances distinctes de Point2D

		// Quand on change / appel une methode sur p1 cela n'a pas d'impact sur
		// p2
	}

}
