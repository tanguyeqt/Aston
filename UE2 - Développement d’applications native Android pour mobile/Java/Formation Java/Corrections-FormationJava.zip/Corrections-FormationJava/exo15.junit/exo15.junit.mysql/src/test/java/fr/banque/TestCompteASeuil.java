/**
 * Copyright : Ferret Renaud 2002 <br/>
 *
 * @version 1.0<br/>
 */
package fr.banque;

import org.junit.Assert;
import org.junit.Test;

import fr.banque.BanqueException;
import fr.banque.CompteASeuil;

/**
 * Test sur la classe fr.banque.CompteASeuil.
 */
public class TestCompteASeuil {

	/**
	 * Test sur la methode retirer de la classe CompteASeuil.
	 *
	 * @throws Exception
	 *             si un probleme survient
	 */
	@Test(expected = BanqueException.class)
	public void testRetirerKo() throws Exception {
		CompteASeuil cas = new CompteASeuil(1, 100d, 50d);
		cas.retirer(100d);
	}

	/**
	 * Test sur la methode retirer de la classe CompteASeuil.
	 *
	 * @throws Exception
	 *             si un probleme survient
	 */
	@Test
	public void testRetirerOk() throws Exception {
		CompteASeuil cas = new CompteASeuil(1, 100d, 50d);
		cas.retirer(25d);
		Assert.assertEquals("Le solde doit etre equal a 25", Double.valueOf(75), cas.getSolde());
	}
}
