package fr.bd;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import fr.banque.Client;
import fr.banque.Compte;
import fr.banque.Operation;

/**
 * Classe de test en JUnit 4 pour la classe fr.bd.AccesBD. <br/>
 */
public class TestAccesBD {
	// Nom du driver pour acceder a la base de donnees.
	// Lire la documentation associee a sa base de donnees pour le connaitre
	private final String dbDriver = "org.hsqldb.jdbc.JDBCDriver";
	// URL d'access a la base de donnees.
	private final String dbUrl = "jdbc:hsqldb:hsql://localhost/banque";
	// Login d'access a la base de donnees.
	private final String dbLogin = "SA";
	// Mot de passe d'access a la base de donnees.
	private final String dbPwd = "";

	private AccesBD accesBD;

	/**
	 * On fabrique un objet pour chaque test et on ouvre la connexion a la base.
	 * <br/>
	 *
	 * @throws Exception
	 *             si on ne peut pas se connecter a la base
	 */
	@Before
	public void openConnection() throws Exception {
		this.accesBD = new AccesBD(this.dbDriver);
		this.accesBD.seConnecter(this.dbUrl, this.dbLogin, this.dbPwd);
	}

	/**
	 * On se deconnecte et on detruit l'objet apres chaque test. <br/>
	 *
	 * @throws Exception
	 *             si on ne peut pas se deconnecter a la base
	 */
	@After
	public void closeConnection() throws Exception {
		this.accesBD.seDeconnecter();
		this.accesBD = null;
	}

	/**
	 * Test de l'authentification avec un login/pwd ok.
	 */
	@Test
	public void testAuthentifierOk() {
		Integer userID = null;
		try {
			userID = this.accesBD.authentifier("df", "df");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Impossible de s'authentifier a la base! (" + e.getMessage() + ")");
		}
		Assert.assertNotNull("L'id ne doit pas etre null", userID);
		Assert.assertEquals("L'id de df est '1'", Integer.valueOf(1), userID);
	}

	/**
	 * Test de l'authentification avec un mauvais login/pwd
	 */
	@Test
	public void testAuthentifierKo() {
		Integer userID = null;
		try {
			userID = this.accesBD.authentifier("df", "wrongpassword");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Impossible de s'authentifier a la base! (" + e.getMessage() + ")");
		}
		Assert.assertNull("L'id doit etre negatif", userID);
	}

	/**
	 * Test de la recuperation de tous les comptes d'un utilisateur.
	 */
	@Test
	public void testSelectCompte() {
		List<Compte> listeCptDf = null;
		try {
			Integer dfId = this.accesBD.authentifier("df", "df");
			Assert.assertNotNull("L'id ne doit pas etre null", dfId);
			listeCptDf = this.accesBD.selectCompte(dfId);
		} catch (SQLException e) {
			e.printStackTrace();
			Assert.fail("Impossible de selectionner un compte! (" + e.getMessage() + ")");
		}
		Assert.assertNotNull("L'utilisateur doit avoir des comptes", listeCptDf);
		Assert.assertTrue("L'utilisateur doit avoir au moins un compte", listeCptDf.size() >= 1);
	}

	/**
	 * Test de la recuperation de toutes les operations attachees a un compte.
	 */
	@Test
	public void testSelectOperation() {
		List<Operation> listeOperations = null;
		try {
			Integer dfId = this.accesBD.authentifier("df", "df");
			Assert.assertNotNull("L'id ne doit pas etre null", dfId);
			List<Compte> listeCptDf = this.accesBD.selectCompte(dfId);
			Assert.assertNotNull("L'utilisateur doit avoir des comptes", listeCptDf);
			Assert.assertTrue("L'utilisateur doit avoir au moins un compte", listeCptDf.size() >= 1);
			Collections.shuffle(listeCptDf);
			Integer cptId = listeCptDf.iterator().next().getNumero();
			listeOperations = this.accesBD.selectOperation(cptId);
		} catch (SQLException e) {
			e.printStackTrace();
			Assert.fail("Impossible de selectionner une operation! (" + e.getMessage() + ")");
		}
		Assert.assertNotNull("La liste des operations n'est jamais null", listeOperations);
	}

	/**
	 * Test de la recuperation de toutes les operations attachees a un compte.
	 * Ajout d'un critere sur les montants.
	 */
	@Test
	public void testSelectOperationOnCriteria() {
		List<Operation> listeOperations = null;
		try {
			Integer dfId = this.accesBD.authentifier("df", "df");
			Assert.assertNotNull("L'id ne doit pas etre null", dfId);
			List<Compte> listeCptDf = this.accesBD.selectCompte(dfId);
			Assert.assertNotNull("L'utilisateur doit avoir des comptes", listeCptDf);
			Assert.assertTrue("L'utilisateur doit avoir au moins un compte", listeCptDf.size() >= 1);
			Collections.shuffle(listeCptDf);
			Integer cptId = listeCptDf.iterator().next().getNumero();
			listeOperations = this.accesBD.selectOperation(cptId, null, null, Boolean.TRUE);
		} catch (SQLException e) {
			e.printStackTrace();
			Assert.fail("Impossible de selectionner une operation! (" + e.getMessage() + ")");
		}
		Assert.assertNotNull("La liste des operations n'est jamais null", listeOperations);
		// On a pris que les credits
		Iterator<Operation> iterOpt = listeOperations.iterator();
		while (iterOpt.hasNext()) {
			Operation operation = iterOpt.next();
			if (operation.getMontant().doubleValue() < 0) {
				Assert.fail("Le critere sur le credit est invalide");
			}
		}
	}

	/**
	 * Test de la recuperation de toutes les operations attachees a un compte.
	 * Validation du comportement sur les dates.
	 */
	@Test
	public void testSelectOperationOnCriteria2() {
		List<Operation> listeOperations = null;
		try {
			Integer dfId = this.accesBD.authentifier("df", "df");
			Assert.assertNotNull("L'id ne doit pas etre null", dfId);
			List<Compte> listeCptDf = this.accesBD.selectCompte(dfId);
			Assert.assertNotNull("L'utilisateur doit avoir des comptes", listeCptDf);
			Assert.assertTrue("L'utilisateur doit avoir au moins un compte", listeCptDf.size() >= 1);
			Collections.shuffle(listeCptDf);
			Integer cptId = listeCptDf.iterator().next().getNumero();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date deb = sdf.parse("2015-02-13");
			java.sql.Date debs = new java.sql.Date(deb.getTime());
			listeOperations = this.accesBD.selectOperation(cptId, debs, debs, null);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Impossible de selectionner une operation! (" + e.getMessage() + ")");
		}
		Assert.assertNotNull("La liste des operations n'est jamais null", listeOperations);
		Assert.assertTrue("La liste doit avoir une valeur", listeOperations.size() == 1);
	}

	/**
	 * Test de la recuperation de toutes les operations attachees a un compte.
	 * Validation du comportement sur les dates.
	 */
	@Test
	public void testSelectOperationOnCriteria3() {
		List<Operation> listeOperations = null;
		try {
			Integer dfId = this.accesBD.authentifier("df", "df");
			Assert.assertNotNull("L'id ne doit pas etre null", dfId);
			List<Compte> listeCptDf = this.accesBD.selectCompte(dfId);
			Assert.assertNotNull("L'utilisateur doit avoir des comptes", listeCptDf);
			Assert.assertTrue("L'utilisateur doit avoir au moins un compte", listeCptDf.size() >= 1);
			Collections.shuffle(listeCptDf);
			Integer cptId = listeCptDf.iterator().next().getNumero();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date deb = sdf.parse("2015-02-13");
			java.sql.Date debs = new java.sql.Date(deb.getTime());
			java.util.Date fin = sdf.parse("2015-02-14");
			java.sql.Date fins = new java.sql.Date(fin.getTime());

			listeOperations = this.accesBD.selectOperation(cptId, debs, fins, null);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Impossible de selectionner une operation! (" + e.getMessage() + ")");
		}
		Assert.assertNotNull("La liste des operations n'est jamais null", listeOperations);
		Assert.assertTrue("La liste doit avoir une valeur", listeOperations.size() == 1);
	}

	/**
	 * Test de la recuperation de toutes les operations attachees a un compte.
	 * Validation du comportement sur les dates.
	 */
	@Test
	public void testSelectOperationOnCriteria4() {
		List<Operation> listeOperations = null;
		try {
			Integer dfId = this.accesBD.authentifier("df", "df");
			Assert.assertNotNull("L'id ne doit pas etre null", dfId);
			List<Compte> listeCptDf = this.accesBD.selectCompte(dfId);
			Assert.assertNotNull("L'utilisateur doit avoir des comptes", listeCptDf);
			Assert.assertTrue("L'utilisateur doit avoir au moins un compte", listeCptDf.size() >= 1);
			Collections.shuffle(listeCptDf);
			Integer cptId = listeCptDf.iterator().next().getNumero();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date deb = sdf.parse("2015-02-14");
			java.sql.Date debs = new java.sql.Date(deb.getTime());
			java.util.Date fin = sdf.parse("2015-02-15");
			java.sql.Date fins = new java.sql.Date(fin.getTime());

			listeOperations = this.accesBD.selectOperation(cptId, debs, fins, null);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Impossible de selectionner une operation! (" + e.getMessage() + ")");
		}
		Assert.assertNotNull("La liste des operations n'est jamais null", listeOperations);
		Assert.assertTrue("La liste doit etre vide", listeOperations.isEmpty());

	}

	/**
	 * Test la recuperation de tous les utilisateurs.
	 */
	@Test
	public void testSelectUtilisateur() {
		List<Client> clients = null;
		try {
			clients = this.accesBD.selectUtilisateur();
		} catch (SQLException e) {
			e.printStackTrace();
			Assert.fail("Impossible de recuperer les utilisateurs! (" + e.getMessage() + ")");
		}
		Assert.assertNotNull("Il doit y avoir des utilisateurs", clients);
		Assert.assertTrue("Il doit y avoir au moins un utilisateur", clients.size() >= 1);
	}

	/**
	 * Test la methode qui realise un virement entre deux comptes.
	 */
	@Test
	public void testFaireVirement() {
		try {
			Integer dfId = this.accesBD.authentifier("df", "df");
			Assert.assertNotNull("L'id ne doit pas etre null", dfId);
			List<Compte> listeCptDf = this.accesBD.selectCompte(dfId);
			Assert.assertNotNull("L'utilisateur doit avoir des comptes", listeCptDf);
			Assert.assertTrue("L'utilisateur doit avoir au moins deux comptes", listeCptDf.size() >= 2);
			Collections.shuffle(listeCptDf);
			Iterator<Compte> iterCpt = listeCptDf.iterator();
			Compte src = iterCpt.next();
			Compte desc = iterCpt.next();
			Integer cptSrc = src.getNumero();
			Integer cptDesc = desc.getNumero();
			final Double unMontant = Double.valueOf(5);
			// On garde sous la main les operations sur chaque compte avant de
			// faire le virement
			List<Operation> operationsAvtVirementCptSrc = this.accesBD.selectOperation(cptSrc);
			List<Operation> operationsAvtVirementCptDesc = this.accesBD.selectOperation(cptDesc);
			// On fait le virement
			this.accesBD.faireVirement(cptSrc, cptDesc, unMontant);
			// Si virement ok
			// On re-recupere les deux comptes de la base pour verifier leur
			// solde
			Compte cptSource = this.accesBD.selectUnCompte(cptSrc);
			Assert.assertNotNull("Le compte source ne peut pas etre null", cptSource);
			Assert.assertEquals("Le solde du compte source doit etre a jour", cptSource.getSolde().doubleValue(),
					src.getSolde().doubleValue() - unMontant.doubleValue(), 0.001);
			Compte cptDestination = this.accesBD.selectUnCompte(cptDesc);
			Assert.assertNotNull("Le compte destination ne peut pas etre null", cptDestination);
			Assert.assertEquals("Le solde du compte destination doit etre a jour",
					cptDestination.getSolde().doubleValue(), desc.getSolde().doubleValue() + unMontant.doubleValue(),
					0.001);
			// On recupere les nouvelles operations sur chaque compte
			List<Operation> operationsAprVirementCptSrc = this.accesBD.selectOperation(cptSrc);
			Assert.assertNotNull("Le compte source doit avoir des operations", operationsAprVirementCptSrc);
			Assert.assertTrue("On doit avoir une operation de plus",
					operationsAprVirementCptSrc.size() - operationsAvtVirementCptSrc.size() == 1);
			List<Operation> operationsAprVirementCptDesc = this.accesBD.selectOperation(cptDesc);
			Assert.assertNotNull("Le compte destination doit avoir des operations", operationsAprVirementCptDesc);
			Assert.assertTrue("On doit avoir une operation de plus",
					operationsAprVirementCptDesc.size() - operationsAvtVirementCptDesc.size() == 1);
		} catch (SQLException e) {
			e.printStackTrace();
			Assert.fail("Impossible de realiser un virement! (" + e.getMessage() + ")");
		}
	}
}
