package fr.banque;

import org.junit.Assert;
import org.junit.Test;

/**
 * Test sur la classe fr.banque.CompteASeuilRemunere.
 */
public class TestCompteASeuilRemunere {

	/**
	 * Test sur la methode retirer de la classe CompteASeuilRemunere.
	 *
	 * @throws Exception
	 *             si un probleme survient
	 */
	@Test(expected = BanqueException.class)
	public void testRetirerKo() throws Exception {
		CompteASeuilRemunere cas = new CompteASeuilRemunere(1, 100d, 0.01d, 50d);
		cas.retirer(100d);
	}

	/**
	 * Test sur la methode retirer de la classe CompteASeuilRemunere.
	 *
	 * @throws Exception
	 *             si un probleme survient
	 */
	@Test
	public void testRetirerOk() throws Exception {
		CompteASeuilRemunere cas = new CompteASeuilRemunere(1, 100d, 0.01d, 50d);
		cas.retirer(25d);
		Assert.assertEquals("Le solde doit etre equal a 25", Double.valueOf(75), cas.getSolde());
	}
}
