package fr.banque;

/**
 * Interface representant un compte a seuil. <br/>
 *
 * Ici, en Java 8 on place le code de la methode retirer.
 *
 * @since 1.8
 */
public interface ICompteASeuil extends ICompte {

	/**
	 * Retire un montant du compte. <br>
	 *
	 * @param unMontant
	 *            le montant retire du compte
	 * @since 1.8
	 */
	@Override
	public default void retirer(double unMontant) {
		double simu = this.getSolde() - unMontant;
		if (simu <= this.getSeuil()) {
			// Pas bon, on ne fait rien, pour l'instant
		} else {
			// On ne peut pas faire de super.retirer dans une interface
			this.setSolde(this.getSolde() - unMontant);
		}
	}

	/**
	 * Recupere le seuil.
	 *
	 * @return le seuil
	 */
	public abstract double getSeuil();

	/**
	 * Modifie la valeur du seuil.
	 *
	 * @param unSeuil
	 *            le nouveau seuil
	 */
	public abstract void setSeuil(double unSeuil);

}