package fr.banque;

/**
 * On fait usage ici de la competence Java 8. <br/>
 *
 * Il est possible de mettre du code dans les methodes des interfaces. <br/>
 *
 * Grace a cela, il n'est plus necessaire de copier/coller les methodes de
 * CompteASeuil dans CompteASeuilRemunere. <br/>
 *
 * @since 1.8
 */
public interface ICompte {

	/**
	 * Donne acces au solde du compte. <br>
	 *
	 * @return le solde du compte
	 */
	public abstract double getSolde();

	/**
	 * Fixe le solde du compte. <br>
	 *
	 * @param unSolde
	 *            le nouveau solde du compte
	 */
	public abstract void setSolde(double unSolde);

	/**
	 * Donne acces au numero du compte. <br>
	 *
	 * @return le numero du compte
	 */
	public abstract int getNumero();

	/**
	 * Ajoute un montant au compte. <br>
	 *
	 * @param unMontant
	 *            le montant ajoute au compte
	 * @since 1.8
	 */
	public default void ajouter(double unMontant) {
		this.setSolde(this.getSolde() + unMontant);
	}

	/**
	 * Retire un montant du compte. <br>
	 *
	 * @param unMontant
	 *            le montant retire du compte
	 * @since 1.8
	 */
	public default void retirer(double unMontant) {
		this.setSolde(this.getSolde() - unMontant);
	}

}