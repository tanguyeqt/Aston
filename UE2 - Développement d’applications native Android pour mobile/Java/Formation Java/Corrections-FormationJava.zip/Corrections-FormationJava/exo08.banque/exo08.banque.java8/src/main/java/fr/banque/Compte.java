package fr.banque;

/**
 * Ceci est la classe Compte. <br/>
 * Ici, on a realise l'interface ICompte et on y a place les code des methode
 * ajouter et retirer.
 */
public class Compte implements ICompte {
	private double solde;
	private int numero;

	/**
	 * Constructeur de l'objet. <br>
	 * Le numero par defaut sera -1.
	 */
	public Compte() {
		this(-1, 0d);
	}

	/**
	 * Constructeur de l'objet. <br>
	 *
	 * @param unNumero
	 *            le numero du compte
	 * @param unSoldeInitial
	 *            le solde initial du compte
	 */
	public Compte(int unNumero, double unSoldeInitial) {
		super();
		// On a choisit de ne pas faire de methode setNumero
		this.numero = unNumero;
		this.setSolde(unSoldeInitial);
	}

	@Override
	public double getSolde() {
		return this.solde;
	}

	@Override
	public void setSolde(double unSolde) {
		this.solde = unSolde;
	}

	@Override
	public int getNumero() {
		return this.numero;
	}

	/**
	 * Formatage du compte sous forme de String utilisable directement par
	 * System.out.println(..);. <br>
	 *
	 * @return une representation chainee de l'objet
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(this.getClass().getName());
		sb.append(" Id=");
		sb.append(this.getNumero());
		sb.append(" Solde=");
		sb.append(this.getSolde());
		return sb.toString();
	}

	/**
	 * Indique si deux comptes sont egaux. <br>
	 *
	 * Deux comptes sont egaux si ils ont le meme numero d'identification.
	 *
	 * @param obj
	 *            l'objet qui sera compare a this
	 * @return <code>true</code> si les deux sont egaux et <code>false</code>
	 *         sinon.
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (obj == this) {
			return true;
		}
		if (obj instanceof Compte && this.getClass() == obj.getClass()) {
			ICompte c = (ICompte) obj;
			return this.getNumero() == c.getNumero();
		}
		return false;
	}

	@Override
	public int hashCode() {
		return (this.getClass().getName() + "_" + this.getNumero()).hashCode();
	}
}
