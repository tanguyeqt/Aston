package fr.banque;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

/**
 * Ceci est la classe parente de tous les objets representes en base de donnees.
 * <br>
 */
public abstract class AbstractEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	private Integer numero;
	/** Tous les objets qui sont interesses par un changement d'etat. */
	private List<PropertyChangeListener> listeners;

	// ---- Note ----
	// Dans ce cas precis d'evenement, a la place de notre liste il est possible
	// de faire usage d'un PropertyChangeSupport
	// private PropertyChangeSupport propertyChangeSupport;

	/**
	 * Constructeur de l'objet. <br>
	 *
	 * @param unNumero
	 *            le numero du compte
	 */
	public AbstractEntity(Integer unNumero) {
		super();
		this.setNumero(unNumero);
	}

	/**
	 * Donne acces au numero du compte. <br>
	 *
	 * @return le numero du compte
	 */
	public Integer getNumero() {
		return this.numero;
	}

	/**
	 * Modificateur pour la propriete numero.
	 *
	 * @param unNumero
	 *            un numero
	 */
	protected final void setNumero(Integer unNumero) {
		Object oldValue = this.numero;
		this.numero = unNumero;
		this.sendPropertyChangeEvent("numero", oldValue, unNumero);
	}

	/**
	 * Formatage du compte sous forme de String utilisable directement par
	 * System.out.println(..);. <br>
	 *
	 * @return une representation chainee de l'objet
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(this.getClass().getName());
		sb.append(" Id=");
		sb.append(this.getNumero());
		return sb.toString();
	}

	/**
	 * Indique si deux comptes sont egaux. <br>
	 *
	 * Deux comptes sont egaux si ils ont le meme numero d'identification.
	 *
	 * @param obj
	 *            l'objet qui sera compare a this
	 * @return <code>true</code> si les deux sont egaux et <code>false</code>
	 *         sinon.
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (obj == this) {
			return true;
		}
		if (obj instanceof AbstractEntity && obj.getClass() == this.getClass()) {
			AbstractEntity c = (AbstractEntity) obj;
			return this.getNumero() == c.getNumero()
					|| this.getNumero() != null && this.getNumero().equals(c.getNumero());
		}
		return false;
	}

	@Override
	public int hashCode() {
		if (this.getNumero() != null) {
			return (this.getClass().getName() + "_" + this.getNumero()).toString().hashCode();
		}
		return super.hashCode();
	}

	/**
	 * Ajoute un objet a la liste de ceux qui sont interesses par un changement
	 * d'etat.
	 *
	 * @param unListener
	 *            objet interesse par un changement d'etat.
	 */
	public void addPropertyChangeListener(PropertyChangeListener unListener) {
		if (unListener == null) {
			return;
		}
		if (this.listeners == null) {
			this.listeners = new Vector<PropertyChangeListener>();
		}
		if (!this.listeners.contains(unListener)) {
			this.listeners.add(unListener);
		}
		// Dans le cas du PropertyChangeSupport
		// if (this.propertyChangeSupport == null) {
		// this.propertyChangeSupport = new PropertyChangeSupport(this);
		// }
		// this.propertyChangeSupport.addPropertyChangeListener(unListener);
	}

	/**
	 * Retire un objet de la liste de ceux qui sont interesses par un changement
	 * d'etat.
	 *
	 * @param unListener
	 *            objet qui n'est plus interesse par un changement d'etat.
	 */
	public void removePropertyChangeListener(PropertyChangeListener unListener) {
		if (unListener == null || this.listeners == null || this.listeners.isEmpty()) {
			return;
		}
		this.listeners.remove(unListener);
		// Dans le cas du PropertyChangeSupport
		// if (this.propertyChangeSupport == null) {
		// return;
		// }
		// this.propertyChangeSupport.removePropertyChangeListener(unListener);
	}

	/**
	 * Methode qui se charge de prevenir tous les autres objets interesses par
	 * les changements d'etats que quelque chose vient de se propduir.
	 *
	 * @param aPropertyName
	 *            le nom de la propriete qui a change d'etat
	 * @param anOldValue
	 *            l'ancienne valeur de cette propriete
	 * @param aNewValue
	 *            la nouvelle valeur de cette propriete
	 */
	protected void sendPropertyChangeEvent(String aPropertyName, Object anOldValue, Object aNewValue) {
		// On ne fait rien si il n'y a personne a prevenir
		if (this.listeners == null || this.listeners.isEmpty()) {
			return;
		}
		// Sinon, on creer un objet representant l'evenement
		PropertyChangeEvent pce = new PropertyChangeEvent(this, aPropertyName, anOldValue, aNewValue);
		// On parcourt tous les objets interesses
		Iterator<PropertyChangeListener> iterListeners = this.listeners.iterator();
		while (iterListeners.hasNext()) {
			PropertyChangeListener pcl = iterListeners.next();
			// Pour leur faire parvenir l'evenement
			pcl.propertyChange(pce);
		}

		// Dans le cas du PropertyChangeSupport
		// if (this.propertyChangeSupport == null) {
		// return;
		// }
		// PropertyChangeEvent pce = new PropertyChangeEvent(this,
		// aPropertyName, anOldValue, aNewValue);
		// this.propertyChangeSupport.firePropertyChange(pce);
	}
}
