package fr.dessin;

/**
 * La classe Point2D. <br/>
 *
 * Une classe se definit par <b>public class [NomDeLaClasse]</b>. <br/>
 * Il est imperatif que cette classe se trouve dans un fichier qui s'appellera
 * [NomDeLaClasse].java. Attention aux minuscules majuscules. <br/>
 *
 * Toute classe Java est un <b>java.lang.Object</b>. <br/>
 *
 * D'une façon plus generale, une classe contient des donnees (attributs) et des
 * fonctionnalites (methodes). <br/>
 *
 * Le mot reserve <b>this</b> represente l'instance courante. <br/>
 */
public class Point2D {
	/** Attribut X. Par defaut en Java, sera initialise à zero. */
	private int x;
	/** Attribut Y. Par defaut en Java, sera initialise à zero. */
	private int y;

	/**
	 * Affiche l'objet sur la sortie standard. <br/>
	 */
	public void afficher() {
		System.out.println("Point2D [" + this.x + ", " + this.y + "]");
		// ou
		// System.out.println("Point2D [" + x + ", " + y + "]");
		// System.out.println("Point2D [" + getX() + ", " + getY() + "]");
		// System.out.format("Point2D [%d, %d]", x, y);
		// System.out.format("Point2D [%d, %d]", getX(), getY());
		// System.out.printf("Point2D [%d, %d]", x, y);
		// System.out.printf("Point2D [%d, %d]", this.getX(), this.getY());
	}

	/**
	 * Recupere la valeur de x.
	 *
	 * @return la valeur de x.
	 */
	public int getX() {
		return this.x;
	}

	/**
	 * Recupere la valeur de y.
	 *
	 * @return la valeur de y.
	 */
	public int getY() {
		return this.y;
	}

	/**
	 * Modifie la valeur de x. <br/>
	 *
	 * @param valX
	 *            la nouvelle valeur de x
	 */
	public void setX(int valX) {
		this.x = valX;
	}

	/**
	 * Modifie la valeur de y. <br/>
	 *
	 * @param valY
	 *            la nouvelle valeur de y
	 */
	public void setY(int valY) {
		this.y = valY;
	}

	/**
	 * Translate le point. <br/>
	 *
	 * @param dX
	 *            valeur de translation en x
	 * @param dY
	 *            valeur de translation en y
	 */
	public void translater(int dX, int dY) {
		this.x += dX;
		this.y += dY;
		// ou
		// x = x + dX;
		// y = y + dY;
		// this.setX(this.getX() + dX);
		// this.setY(this.getY() + dY);
	}
}