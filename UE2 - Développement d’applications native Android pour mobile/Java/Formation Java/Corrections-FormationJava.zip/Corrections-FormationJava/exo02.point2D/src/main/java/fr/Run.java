package fr;

import fr.dessin.Point2D;

/**
 * La classe de lancement. <br/>
 */
public class Run {

	/**
	 * Pour tester. <br/>
	 *
	 * @param args
	 *            les arguments
	 */
	public static void main(String[] args) {
		// Creation d'une variable de type Point2D et qui s'appelera p1
		Point2D p1 = new Point2D();
		// p1 est
		// - une variable locale a la methode main
		// - mais aussi, une instance de Point2D

		System.out.println("Par defaut :");
		// Appel de la methode afficher sur l'instance p1
		p1.afficher();
		// Appel de la methode translater sur l'instance p1
		// avec deux parametres de valeurs 5 et 8
		p1.translater(5, 8);
		System.out.println("Apres translation :");
		p1.afficher();
		// Appel de la methode setX sur l'instance p1
		p1.setX(19);
		System.out.println("Apres modification de sa valeur en x :");
		p1.afficher();
	}

}
