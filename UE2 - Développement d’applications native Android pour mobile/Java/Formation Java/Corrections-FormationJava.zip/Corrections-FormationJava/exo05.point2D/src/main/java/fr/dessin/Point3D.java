package fr.dessin;

/**
 * Classe qui represente un point en 3 dimension. <br/>
 * Herite d'un point en deux dimensions. <br/>
 * <br/>
 * En Java vous ne pouvez heriter que d'une seule classe (mot clef extends).
 */
public class Point3D extends Point2D {
	private int z;

	/**
	 * Constructeur.
	 */
	public Point3D() {
		this(0, 0, 0);
		// Chainage de constructeur
		// On commence par ecrire le plus complique
		// Puis les autres y font appel
	}

	/**
	 * Constructeur.
	 *
	 * @param vX
	 *            valeur pour X
	 * @param vY
	 *            valeur pour Y
	 * @param vZ
	 *            valeur pour Z
	 */
	public Point3D(int vX, int vY, int vZ) {
		super(vX, vY);
		// On fait appel au constructeur parent pour gerer x et y
		// Mot clef super avec un '('
		// super(xxxx); : Doit imperativement etre sur la
		// premiere ligne de code du constructeur
		this.setZ(vZ);
	}

	/**
	 * Recupere la valeur de Z
	 *
	 * @return la valeur de Z
	 */
	public int getZ() {
		return this.z;
	}

	/**
	 * Modifie la valeur de Z
	 *
	 * @param dZ
	 *            la nouvelle valeur de z
	 */
	public void setZ(int dZ) {
		this.z = dZ;
	}

	/**
	 * Translate le point sur 3 axes.
	 *
	 * @param dX
	 *            valeur de translation en x
	 * @param dY
	 *            valeur de translation en y
	 * @param dZ
	 *            valeur de translation en z
	 */
	public void translater(int dX, int dY, int dZ) {
		// On fait appel a la methode parente pour gerer x et y
		// Mot clef super avec un '.'
		super.translater(dX, dY);
		// Puis on gere le z
		this.setZ(this.getZ() + dZ);
	}

	@Override
	public String toString() {
		StringBuilder resu = new StringBuilder();
		resu.append(super.toString());
		// on retire le ']' en trop
		resu.delete(resu.length() - 1, resu.length());
		// Notez que le getClass de parent va bien prendre Point3D
		resu.append(", z=").append(this.getZ()).append(']');
		return resu.toString();
	}

	@Override
	public int hashCode() {
		return (this.getClass() + "_" + this.getX() + "_" + this.getY() + "_" + this.getZ()).hashCode();

	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (obj instanceof Point3D) {
			Point3D other = (Point3D) obj;
			return this.getX() == other.getX() && this.getY() == other.getY() && this.getZ() == other.getZ();
		}
		return false;
	}

}
