package fr.dessin;

/**
 * La classe Point2D. <br/>
 */
public class Point2D {
	/**
	 * Attribut compteur. Ce dernier est static, il appartient a la famille de
	 * toutes les instances de Point2D.
	 */
	private static int compteur;

	/** Attribut X. Par defaut en Java, sera initialise a zero. */
	private int x;
	/** Attribut Y. Par defaut en Java, sera initialise a zero. */
	private int y;

	/**
	 * Constructeur.
	 */
	public Point2D() {
		this(0, 0);
		// Ici on appel le constructeur de Point2D qui prend deux parametres
		// On fait un chenage de constructeur
	}

	/**
	 * Constructeur.
	 *
	 * @param vX
	 *            valeur pour x
	 * @param vY
	 *            valeur pour y
	 */
	public Point2D(int vX, int vY) {
		super();
		this.setX(vX);
		this.setY(vY);
		// Un attribut static est prefixe par le nom de la classe
		// JAMAIS par this
		Point2D.compteur++;
	}

	/**
	 * Transforme l'objet en chaine de caracteres.
	 *
	 * @return l'objet sous forme de chaine de caracteres.
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		// getClass permet de recuperer un objet java.lang.Class
		builder.append(this.getClass().getName());
		builder.append(" [x=");
		builder.append(this.getX());
		builder.append(", y=");
		builder.append(this.getY());
		builder.append(']');
		return builder.toString();
	}

	@Override
	public int hashCode() {
		return (this.getClass() + "_" + this.getX() + "_" + this.getY()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (obj instanceof Point2D) {
			Point2D other = (Point2D) obj;
			return this.getX() == other.getX() && this.getY() == other.getY();
		}
		return false;
	}

	/**
	 * Recupere la valeur de x.
	 *
	 * @return la valeur de x.
	 */
	public int getX() {
		return this.x;
	}

	/**
	 * Recupere la valeur de y.
	 *
	 * @return la valeur de y.
	 */
	public int getY() {
		return this.y;
	}

	/**
	 * Modifie la valeur de x. <br/>
	 *
	 * @param valX
	 *            la nouvelle valeur de x
	 */
	public void setX(int valX) {
		this.x = valX;
	}

	/**
	 * Modifie la valeur de y. <br/>
	 *
	 * @param valY
	 *            la nouvelle valeur de y
	 */
	public void setY(int valY) {
		this.y = valY;
	}

	/**
	 * Translate le point. <br/>
	 *
	 * @param dX
	 *            valeur de translation en x
	 * @param dY
	 *            valeur de translation en y
	 */
	public void translater(int dX, int dY) {
		this.setX(this.getX() + dX);
		this.setY(this.getY() + dY);
	}

	/**
	 * Methode qui recupere la valeur du compteur. <br/>
	 * Une methode static devrait toujours etre final, car il n'y a pas en Java
	 * de surcharge possible sur une methode static.
	 *
	 * @return la valeur du compteur.
	 */
	public static final int getCompteur() {
		return Point2D.compteur;
	}
}