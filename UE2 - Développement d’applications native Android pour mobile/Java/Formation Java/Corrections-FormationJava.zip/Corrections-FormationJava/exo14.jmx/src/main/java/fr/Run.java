package fr;

import java.lang.management.ManagementFactory;

import javax.management.MBeanServer;
import javax.management.ObjectName;

import fr.jmx.Calculatrice;
import fr.jmx.CalculatriceMBean;

/**
 * Classe qui fabrique le bean JMX, le reference et attend. <br/>
 * Apres avoir lance cette classe, tapez jconsole dans un shell. <br/>
 */
public class Run {

	/**
	 * Test qui fabrique un bean JMX et le laisse a disposition.
	 *
	 * @param args
	 *            Ne sert pas ici
	 */
	public static void main(String[] args) {
		// Recupere l'annuaire de bean JMX
		MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
		try {
			// Nom de l'objet
			ObjectName name = new ObjectName("fr.jmx:type=Calculatrice");
			// Construction de l'objet
			CalculatriceMBean mbean = new Calculatrice();
			// Inscription de l'objet dans l'annuaire
			mbs.registerMBean(mbean, name);
			// On attend
			System.out.println("Maintenant, ouvrez un shell et lancez jconsole");
			System.out.println("N'oubliez pas de killer le processus a la fin (carre rouge)");
			Thread.sleep(Long.MAX_VALUE);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
