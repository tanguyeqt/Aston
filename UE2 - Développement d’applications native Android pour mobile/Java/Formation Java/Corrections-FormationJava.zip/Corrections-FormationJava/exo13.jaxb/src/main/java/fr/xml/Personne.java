package fr.xml;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * La classe Personne. <br/>
 */
@XmlRootElement(name = "personne")
@XmlAccessorType(XmlAccessType.NONE)
public class Personne {
	@XmlElement
	private String nom;
	@XmlElement
	private String prenom;
	@XmlElement
	@XmlJavaTypeAdapter(DateAdapter.class)
	private Date dateNaissance;
	@XmlElement(name = "adresse")
	@XmlElementWrapper(name = "adresses")
	private List<Adresse> adresses;

	/**
	 * Constructeur.
	 */
	public Personne() {
		super();
	}

	/**
	 * Recupere les adresses.
	 *
	 * @return the adresses
	 */
	public List<Adresse> getAdresses() {
		return this.adresses;
	}

	/**
	 * Modifie les adresses.
	 *
	 * @param adresses
	 *            the adresses to set
	 */
	public void setAdresses(List<Adresse> adresses) {
		this.adresses = adresses;
	}

	/**
	 * Recupere le nom.
	 *
	 * @return the nom
	 */
	public String getNom() {
		return this.nom;
	}

	/**
	 * Modifie le nom
	 *
	 * @param nom
	 *            the nom to set
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}

	/**
	 * Recupere le prenom
	 *
	 * @return the prenom
	 */
	public String getPrenom() {
		return this.prenom;
	}

	/**
	 * Modifie le prenom
	 *
	 * @param prenom
	 *            the prenom to set
	 */
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	/**
	 * Recupere la date de naissance
	 *
	 * @return the dateNaissance
	 */
	public Date getDateNaissance() {
		return this.dateNaissance;
	}

	/**
	 * Modifie la date de naissance
	 *
	 * @param dateNaissance
	 *            the dateNaissance to set
	 */
	public void setDateNaissance(Date dateNaissance) {
		this.dateNaissance = dateNaissance;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(this.getClass().getSimpleName());
		builder.append(" [nom=");
		builder.append(this.getNom());
		builder.append(", prenom=");
		builder.append(this.getPrenom());
		builder.append(", dateNaissance=");
		builder.append(this.getDateNaissance());
		if (this.getAdresses() != null && !this.getAdresses().isEmpty()) {
			builder.append(", adresses=");
			builder.append(this.getAdresses());
		}
		builder.append("]");
		return builder.toString();
	}

}
