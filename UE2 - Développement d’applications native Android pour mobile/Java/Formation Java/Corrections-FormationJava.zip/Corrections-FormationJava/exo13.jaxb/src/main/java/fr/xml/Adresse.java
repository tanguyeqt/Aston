package fr.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Classe qui represente une adresse. <br/>
 */
@XmlRootElement(name = "adresse")
@XmlAccessorType(XmlAccessType.NONE)
public class Adresse {
	@XmlAttribute
	private String ville;
	@XmlAttribute
	private int codePostal;
	@XmlElement
	private String rue;
	@XmlAttribute
	private String pays;

	/**
	 * Constructeur.
	 */
	public Adresse() {
		super();
	}

	/**
	 * Recupere la ville.
	 *
	 * @return the ville
	 */
	public String getVille() {
		return this.ville;
	}

	/**
	 * Modifie la ville.
	 *
	 * @param ville
	 *            the ville to set
	 */
	public void setVille(String ville) {
		this.ville = ville;
	}

	/**
	 * Recupere le code postal.
	 *
	 * @return the codePostal
	 */
	public int getCodePostal() {
		return this.codePostal;
	}

	/**
	 * Modifie le code postal.
	 *
	 * @param codePostal
	 *            the codePostal to set
	 */
	public void setCodePostal(int codePostal) {
		this.codePostal = codePostal;
	}

	/**
	 * Recupere la rue.
	 *
	 * @return the rue
	 */
	public String getRue() {
		return this.rue;
	}

	/**
	 * Modifie la rue.
	 *
	 * @param rue
	 *            the rue to set
	 */
	public void setRue(String rue) {
		this.rue = rue;
	}

	/**
	 * Recupere le pays.
	 *
	 * @return the pays
	 */
	public String getPays() {
		return this.pays;
	}

	/**
	 * Modifie le pays.
	 *
	 * @param pays
	 *            the pays to set
	 */
	public void setPays(String pays) {
		this.pays = pays;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(this.getClass().getSimpleName());
		builder.append(" [ville=");
		builder.append(this.getVille());
		builder.append(", codePostal=");
		builder.append(this.getCodePostal());
		builder.append(", rue=");
		builder.append(this.getRue());
		builder.append(", pays=");
		builder.append(this.getPays());
		builder.append("]");
		return builder.toString();
	}

}
