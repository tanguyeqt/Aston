package fr.banque;

/**
 * Test sur la classe fr.banque.CompteASeuilRemunere.
 */
public class TestCompteASeuilRemunere {

}
