package fr.banque;

/**
 * Test sur la classe fr.banque.Client.
 */
public class TestClient {

}
